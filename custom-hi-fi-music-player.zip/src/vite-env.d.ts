/// <reference types="vite/client" />

interface Window {
  saltbee?: {
    dock: (on: boolean) => void;
    dockExpand?: (expanded: boolean) => void;
    minimize: () => void;
    maximize: () => void;
    close: () => void;
    isElectron: boolean;
  };
}
