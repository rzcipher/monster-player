import { useEffect, useState } from "react";
import { useStore, getEngine } from "./store";
import TitleBar from "./components/TitleBar";
import Sidebar from "./components/Sidebar";
import TrackTable from "./components/TrackTable";
import CoverGrid from "./components/CoverGrid";
import PlayerBar from "./components/PlayerBar";
import RightPanel from "./components/RightPanel";
import NowPlaying from "./components/NowPlaying";
import SoundEffects from "./components/SoundEffects";
import DockBar from "./components/DockBar";
import { TagEditor, SmartEditor, SettingsDialog, QuarantineDialog, SleepDialog, PromptDialog } from "./components/Dialogs";

function MainArea() {
  const view = useStore((s) => s.view);
  return (
    <div className="flex-1 flex min-h-0">
      <Sidebar />
      <main className="flex-1 flex flex-col min-w-0 themed-bg">{view === "table" ? <TrackTable /> : <CoverGrid />}</main>
      <RightPanel />
    </div>
  );
}

export default function App() {
  const s = useStore();
  const [dragging, setDragging] = useState(false);

  useEffect(() => { s.init(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // keyboard shortcuts
  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement).tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      const st = useStore.getState();
      if (e.code === "Space") { e.preventDefault(); st.togglePlay(); }
      else if (e.key === "ArrowRight") st.seek(getEngine().position + (e.shiftKey ? 30 : 5));
      else if (e.key === "ArrowLeft") st.seek(getEngine().position - (e.shiftKey ? 30 : 5));
      else if (e.key === "ArrowUp" && e.ctrlKey) st.setVolume(Math.min(1, st.volume + 0.05));
      else if (e.key === "ArrowDown" && e.ctrlKey) st.setVolume(Math.max(0, st.volume - 0.05));
      else if (e.key.toLowerCase() === "n" && e.ctrlKey) st.next(true);
      else if (e.key.toLowerCase() === "p" && e.ctrlKey) st.prev();
      else if (e.key.toLowerCase() === "l" && !e.ctrlKey) st.nowPlayingOpen && st.nowPlayingTab === "lyrics" ? st.closeNowPlaying() : st.openNowPlaying("lyrics");
      else if (e.key.toLowerCase() === "e" && e.ctrlKey) { e.preventDefault(); st.set({ fxOpen: true }); }
      else if (e.key.toLowerCase() === "f" && e.ctrlKey) { e.preventDefault(); (document.querySelector('input[placeholder^="Quick search"]') as HTMLInputElement | null)?.focus(); }
      else if (e.key.toLowerCase() === "d" && e.ctrlKey) { e.preventDefault(); st.toggleDock(); }
      else if (e.key === "Enter" && st.selected.length === 1) st.playTrack(st.selected[0]);
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, []);

  // media keys / OS media session
  useEffect(() => {
    if (!("mediaSession" in navigator)) return;
    const ms = navigator.mediaSession;
    const st = () => useStore.getState();
    ms.setActionHandler("play", () => st().togglePlay());
    ms.setActionHandler("pause", () => st().togglePlay());
    ms.setActionHandler("nexttrack", () => st().next(true));
    ms.setActionHandler("previoustrack", () => st().prev());
    ms.setActionHandler("seekto", (d) => d.seekTime !== undefined && st().seek(d.seekTime));
  }, []);

  // drag & drop = disk mode
  useEffect(() => {
    const over = (e: DragEvent) => { e.preventDefault(); setDragging(true); };
    const leave = () => setDragging(false);
    const drop = (e: DragEvent) => { e.preventDefault(); setDragging(false); if (e.dataTransfer?.files.length) useStore.getState().importFiles(e.dataTransfer.files, !e.shiftKey); };
    window.addEventListener("dragover", over); window.addEventListener("dragleave", leave); window.addEventListener("drop", drop);
    return () => { window.removeEventListener("dragover", over); window.removeEventListener("dragleave", leave); window.removeEventListener("drop", drop); };
  }, []);

  return (
    <div className="h-full flex flex-col themed-bg text-fg overflow-hidden">
      {s.docked ? (
        <>
          <DockBar />
          {s.dockExpanded ? (
            <div className="flex-1 flex flex-col min-h-0 border-b border-subtle shadow-2xl fade-in">
              <MainArea />
              <PlayerBar />
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center text-muted text-[12px] select-none" style={{ background: "repeating-linear-gradient(45deg, transparent 0 12px, rgba(255,255,255,0.015) 12px 24px)" }}>
              <div className="text-center max-w-md">
                <div className="text-[14px] mb-1">Docked to the top edge — AIMP style</div>
                <div>In the native shell this area is your desktop: the window shrinks to the bar height, stays always-on-top, and other windows tile below it. Press ▾ to drop the library down, or Ctrl+D to undock.</div>
              </div>
            </div>
          )}
        </>
      ) : (
        <>
          <TitleBar />
          <MainArea />
          <PlayerBar />
        </>
      )}

      {s.nowPlayingOpen && <NowPlaying />}
      {s.fxOpen && <SoundEffects />}
      {s.tagEditorId && <TagEditor key={s.tagEditorId} />}
      {s.smartEditorId && <SmartEditor key={s.smartEditorId} />}
      {s.settingsOpen && <SettingsDialog />}
      {s.quarantineOpen && <QuarantineDialog />}
      {s.sleepOpen && <SleepDialog />}
      {s.promptReq && <PromptDialog key={s.promptReq.title} />}
      {dragging && (
        <div className="fixed inset-0 z-[300] bg-black/60 flex items-center justify-center pointer-events-none fade-in">
          <div className="glass border border-subtle rounded-2xl px-10 py-8 text-center">
            <div className="text-2xl font-semibold mb-1">Drop to play (disk mode)</div>
            <div className="text-muted">FLAC · ALAC · MP3 · AAC · Opus · Vorbis · WAV · AIFF · CUE — hold Shift to import into the library instead</div>
          </div>
        </div>
      )}
      {s.scan.active && (
        <div className="fixed bottom-[calc(var(--player-h)+8px)] left-1/2 -translate-x-1/2 z-[90] glass border border-subtle rounded-full px-4 py-1.5 text-[12px] flex items-center gap-3">
          <span className="w-2 h-2 rounded-full accent-bg pulse-dot" />Scanning {s.scan.done}/{s.scan.total || "…"} <span className="text-muted truncate max-w-[300px]">{s.scan.current}</span>
        </div>
      )}
    </div>
  );
}
