import type { Palette } from "../types";

export const DEFAULT_PALETTE: Palette = {
  bg: "#0d0b14",
  surface: "#17141f",
  accent: "#8b5cf6",
  accent2: "#c084fc",
  text: "#f4f1fa",
  muted: "#9b93ad",
  vibrant: "#a78bfa",
  dominant: "#2a2336",
};

function rgbToHsl(r: number, g: number, b: number): [number, number, number] {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0, s = 0;
  const l = (max + min) / 2;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = (g - b) / d + (g < b ? 6 : 0); break;
      case g: h = (b - r) / d + 2; break;
      default: h = (r - g) / d + 4;
    }
    h /= 6;
  }
  return [h * 360, s, l];
}
export function hsl(h: number, s: number, l: number) {
  return `hsl(${Math.round(h)} ${Math.round(s * 100)}% ${Math.round(l * 100)}%)`;
}

const cache = new Map<string, Palette>();

export async function extractPalette(url: string): Promise<Palette> {
  if (cache.has(url)) return cache.get(url)!;
  const img = new Image();
  img.crossOrigin = "anonymous";
  img.src = url;
  try {
    await img.decode();
  } catch {
    return DEFAULT_PALETTE;
  }
  const S = 48;
  const c = document.createElement("canvas");
  c.width = S; c.height = S;
  const ctx = c.getContext("2d", { willReadFrequently: true })!;
  ctx.drawImage(img, 0, 0, S, S);
  let data: Uint8ClampedArray;
  try { data = ctx.getImageData(0, 0, S, S).data; } catch { return DEFAULT_PALETTE; }

  // bucket into 4-bit-ish histogram of hue/sat/light
  const buckets = new Map<string, { n: number; r: number; g: number; b: number; s: number; l: number; h: number }>();
  for (let i = 0; i < data.length; i += 4) {
    const r = data[i], g = data[i + 1], b = data[i + 2];
    const [h, s, l] = rgbToHsl(r, g, b);
    const key = `${Math.round(h / 20)}-${Math.round(s * 4)}-${Math.round(l * 5)}`;
    const bk = buckets.get(key) || { n: 0, r: 0, g: 0, b: 0, s: 0, l: 0, h: 0 };
    bk.n++; bk.r += r; bk.g += g; bk.b += b; bk.s += s; bk.l += l; bk.h += h;
    buckets.set(key, bk);
  }
  const list = [...buckets.values()].map((b) => ({
    n: b.n, r: b.r / b.n, g: b.g / b.n, b: b.b / b.n, s: b.s / b.n, l: b.l / b.n, h: b.h / b.n,
  }));
  list.sort((a, b) => b.n - a.n);
  const dominant = list[0];
  // vibrant: weighted by saturation * count, avoid extremes of lightness
  const vibrant = list
    .filter((x) => x.l > 0.18 && x.l < 0.85)
    .sort((a, b) => b.s * Math.sqrt(b.n) - a.s * Math.sqrt(a.n))[0] || dominant;
  const second = list
    .filter((x) => x !== vibrant && x.l > 0.2 && x.l < 0.85 && Math.abs(x.h - vibrant.h) > 25)
    .sort((a, b) => b.s * Math.sqrt(b.n) - a.s * Math.sqrt(a.n))[0] || vibrant;

  const accH = vibrant.h, accS = Math.max(0.45, Math.min(0.9, vibrant.s + 0.15));
  const domH = dominant.h, domS = Math.min(0.5, dominant.s);
  const palette: Palette = {
    bg: hsl(domH, Math.max(0.12, domS * 0.7), 0.06),
    surface: hsl(domH, Math.max(0.1, domS * 0.6), 0.1),
    accent: hsl(accH, accS, 0.6),
    accent2: hsl(second.h, Math.max(0.4, second.s), 0.68),
    text: hsl(domH, 0.2, 0.96),
    muted: hsl(domH, 0.12, 0.62),
    vibrant: `rgb(${Math.round(vibrant.r)} ${Math.round(vibrant.g)} ${Math.round(vibrant.b)})`,
    dominant: `rgb(${Math.round(dominant.r)} ${Math.round(dominant.g)} ${Math.round(dominant.b)})`,
  };
  cache.set(url, palette);
  return palette;
}

export function applyPalette(p: Palette) {
  const r = document.documentElement.style;
  r.setProperty("--c-bg", p.bg);
  r.setProperty("--c-surface", p.surface);
  r.setProperty("--c-accent", p.accent);
  r.setProperty("--c-accent2", p.accent2);
  r.setProperty("--c-text", p.text);
  r.setProperty("--c-muted", p.muted);
  r.setProperty("--c-vibrant", p.vibrant);
  r.setProperty("--c-dominant", p.dominant);
}
