import { Play, Pause, SkipBack, SkipForward, ChevronDown, ChevronUp, PanelTopClose, Volume2, Shuffle, Repeat, Repeat1, MicVocal } from "lucide-react";
import { useStore } from "../store";
import { usePosition } from "../hooks";
import { fmtTime } from "../lib/util";
import { Cover } from "./ui";
import { Waveform } from "./PlayerBar";

/** AIMP-style "docked to screen edge" compact bar. In the native shell the window itself is resized to this height and set always-on-top. */
export default function DockBar() {
  const s = useStore();
  const t = s.tracks.find((x) => x.id === s.currentId) || null;
  const { pos, dur } = usePosition(10);
  const RepeatIcon = s.repeat === "one" ? Repeat1 : Repeat;
  return (
    <div className="drag-region h-[56px] shrink-0 flex items-center gap-3 px-3 glass border-b border-subtle shadow-2xl" style={{ background: "color-mix(in srgb, var(--c-surface) 88%, var(--c-accent) 12%)" }}>
      <div className="flex items-center gap-2 pr-3 border-r border-subtle">
        <div className="w-6 h-6 rounded-md flex items-center justify-center text-white font-black text-[13px]" style={{ background: "linear-gradient(135deg, var(--c-accent), var(--c-accent2))" }}>S</div>
      </div>
      <button className="no-drag" onClick={() => s.openNowPlaying()}><Cover url={t?.coverUrl || null} size={40} rounded="rounded" /></button>
      <div className="w-[220px] min-w-0 no-drag">
        <div className="text-[13px] font-semibold truncate">{t?.title || "SaltBee"}</div>
        <div className="text-[11px] text-muted truncate">{t ? `${t.artist} · ${t.codec} ${Math.round(t.sampleRate / 1000)}k` : "docked to top — click ▾ to expand"}</div>
      </div>
      <div className="flex items-center gap-1 no-drag">
        <button onClick={s.prev} className="w-8 h-8 rounded hover:bg-white/10 inline-flex items-center justify-center"><SkipBack size={16} /></button>
        <button onClick={s.togglePlay} className="w-9 h-9 rounded-full inline-flex items-center justify-center text-black" style={{ background: "var(--c-accent2)" }}>{s.playing ? <Pause size={16} fill="currentColor" /> : <Play size={16} fill="currentColor" className="ml-0.5" />}</button>
        <button onClick={() => s.next(true)} className="w-8 h-8 rounded hover:bg-white/10 inline-flex items-center justify-center"><SkipForward size={16} /></button>
      </div>
      <span className="text-[11px] text-muted tabular-nums no-drag">{fmtTime(pos)}</span>
      <div className="flex-1 no-drag"><Waveform height={26} /></div>
      <span className="text-[11px] text-muted tabular-nums no-drag">{fmtTime(dur)}</span>
      <div className="flex items-center gap-1 no-drag">
        <button onClick={s.toggleShuffle} className={`w-7 h-7 rounded hover:bg-white/10 inline-flex items-center justify-center ${s.shuffle ? "accent-text" : "text-muted"}`}><Shuffle size={14} /></button>
        <button onClick={s.cycleRepeat} className={`w-7 h-7 rounded hover:bg-white/10 inline-flex items-center justify-center ${s.repeat !== "off" ? "accent-text" : "text-muted"}`}><RepeatIcon size={14} /></button>
        <button onClick={() => s.openNowPlaying("lyrics")} className="w-7 h-7 rounded hover:bg-white/10 inline-flex items-center justify-center text-muted"><MicVocal size={14} /></button>
        <Volume2 size={14} className="text-muted ml-1" />
        <input type="range" min={0} max={1} step={0.01} value={s.volume} onChange={(e) => s.setVolume(+e.target.value)} className="fader accent w-[80px]" style={{ ["--pct" as string]: `${s.volume * 100}%` }} />
      </div>
      <div className="flex items-center gap-1 no-drag pl-2 border-l border-subtle">
        <button onClick={() => s.setDockExpanded(!s.dockExpanded)} title={s.dockExpanded ? "Collapse" : "Expand library"} className="w-8 h-8 rounded hover:bg-white/10 inline-flex items-center justify-center">{s.dockExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}</button>
        <button onClick={s.toggleDock} title="Undock (restore window)" className="w-8 h-8 rounded hover:bg-white/10 inline-flex items-center justify-center text-muted"><PanelTopClose size={16} /></button>
      </div>
    </div>
  );
}
