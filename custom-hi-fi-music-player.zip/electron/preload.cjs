const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("saltbee", {
  isElectron: true,
  dock: (on) => ipcRenderer.send("win:dock", on),
  dockExpand: (expanded) => ipcRenderer.send("win:dockExpand", expanded),
  minimize: () => ipcRenderer.send("win:minimize"),
  maximize: () => ipcRenderer.send("win:maximize"),
  close: () => ipcRenderer.send("win:close"),
});
