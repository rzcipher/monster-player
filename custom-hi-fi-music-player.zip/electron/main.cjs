// SaltBee native shell — run with:  npx electron electron/main.cjs   (after `npm run build`)
// Provides: frameless window, AIMP-style dock-to-top (always-on-top strip across the screen),
// window controls, and a local CLI bridge (POST http://127.0.0.1:7788/action) that spawns your tagging CLI.
const { app, BrowserWindow, ipcMain, screen, shell } = require("electron");
const path = require("path");
const http = require("http");
const { spawn } = require("child_process");

let win;
let normalBounds = null;
const DOCK_HEIGHT = 56;
const DOCK_EXPANDED_HEIGHT = 720;

// Feed the audio engine the highest-fidelity path Chromium offers on Windows (WASAPI) — exclusive/ASIO
// is handled by the optional native addon (see README); these flags remove Chromium's own resampler stages.
app.commandLine.appendSwitch("audio-buffer-size", "512");
app.commandLine.appendSwitch("disable-features", "AudioServiceOutOfProcess");
app.commandLine.appendSwitch("autoplay-policy", "no-user-gesture-required");
app.commandLine.appendSwitch("enable-features", "WebAudioSinkSelection");

function createWindow() {
  win = new BrowserWindow({
    width: 1500, height: 900, minWidth: 900, minHeight: 56, frame: false, backgroundColor: "#0d0b14",
    titleBarStyle: "hidden", show: false,
    webPreferences: { preload: path.join(__dirname, "preload.cjs"), contextIsolation: true, nodeIntegration: false, backgroundThrottling: false },
  });
  win.loadFile(path.join(__dirname, "..", "dist", "index.html"));
  win.once("ready-to-show", () => win.show());
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: "deny" }; });
}

ipcMain.on("win:minimize", () => win?.minimize());
ipcMain.on("win:maximize", () => (win?.isMaximized() ? win.unmaximize() : win?.maximize()));
ipcMain.on("win:close", () => win?.close());

// AIMP-style docking: window becomes a strip along the top edge of the display, always on top,
// visible on all workspaces, and (on Windows) reserves the space like an app bar.
ipcMain.on("win:dock", (_e, on) => {
  if (!win) return;
  if (on) {
    normalBounds = win.getBounds();
    const d = screen.getDisplayNearestPoint(screen.getCursorScreenPoint()).workArea;
    win.unmaximize();
    win.setResizable(false);
    win.setBounds({ x: d.x, y: d.y, width: d.width, height: DOCK_HEIGHT });
    win.setAlwaysOnTop(true, "screen-saver");
    win.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
    win.setSkipTaskbar(false);
  } else {
    win.setAlwaysOnTop(false);
    win.setVisibleOnAllWorkspaces(false);
    win.setResizable(true);
    if (normalBounds) win.setBounds(normalBounds);
  }
});
ipcMain.on("win:dockExpand", (_e, expanded) => {
  if (!win) return;
  const b = win.getBounds();
  win.setBounds({ ...b, height: expanded ? DOCK_EXPANDED_HEIGHT : DOCK_HEIGHT });
});

// ---- CLI bridge: the renderer POSTs {action, path, isrc, mbid} and we run the user's CLI ----
// Configure the executable via SALTBEE_CLI env var, e.g. SALTBEE_CLI="python -m mymusiccli"
function startCliBridge() {
  const server = http.createServer((req, res) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    if (req.method === "OPTIONS") { res.writeHead(204); return res.end(); }
    if (req.method !== "POST" || req.url !== "/action") { res.writeHead(404); return res.end(); }
    let body = "";
    req.on("data", (c) => (body += c));
    req.on("end", () => {
      try {
        const { action, path: file, isrc, mbid } = JSON.parse(body);
        const cli = process.env.SALTBEE_CLI || "musiccli";
        const args = { "fix-metadata": ["fix", file, ...(mbid ? ["--mbid", mbid] : isrc ? ["--isrc", isrc] : [])], retranslate: ["translate", file, "--force"], "demucs-acapella": ["demucs", file, "--stem", "vocals", "--sidecar"], retag: ["retag", file] }[action];
        if (!args) { res.writeHead(400); return res.end("unknown action"); }
        const child = spawn(cli, args, { shell: true });
        let out = "";
        child.stdout.on("data", (d) => (out += d)); child.stderr.on("data", (d) => (out += d));
        child.on("close", (code) => { res.writeHead(code === 0 ? 200 : 500, { "Content-Type": "text/plain" }); res.end(out); });
      } catch (e) { res.writeHead(400); res.end(String(e)); }
    });
  });
  server.listen(7788, "127.0.0.1");
}

app.whenReady().then(() => { createWindow(); startCliBridge(); });
app.on("window-all-closed", () => app.quit());
